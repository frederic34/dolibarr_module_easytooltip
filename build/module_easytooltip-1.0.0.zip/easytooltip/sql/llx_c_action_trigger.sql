--
-- Running the script to add triggers
-- For example
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_DRAFT', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_CREATE', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_VALIDATE', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_MODIFY', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_ACCEPT', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_DENIED', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_REOPEN', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_UNVALIDATE', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- INSERT INTO `llx_c_action_trigger` (`rowid`, `elementtype`, `code`, `label`, `description`, `rang`) VALUES (NULL, 'easytooltip', 'MYCLASSNAME_SENTBYMAIL', 'MYCLASSNAME create', 'A MYCLASSNAME is created', '0000000');
-- 


--ADD Call trigger IN TABLE