
## Unreleased (2023-11-03)

#### :bug: Bug Fix
* [#1](https://github.com/Net-Logic/dolibarr_module_easytooltip/pull/1) add some objects that can have an underscore ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
