
## Unreleased (2025-01-24)

#### :rocket: Enhancement
* [#9](https://github.com/frederic34/dolibarr_module_easytooltip/pull/9) add product description ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#8](https://github.com/frederic34/dolibarr_module_easytooltip/pull/8) fix duration units ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.0 (2024-09-23)

#### :rocket: Enhancement
* [#5](https://github.com/frederic34/dolibarr_module_easytooltip/pull/5) add service duration ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#1](https://github.com/frederic34/dolibarr_module_easytooltip/pull/1) add some objects that can have an underscore ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
