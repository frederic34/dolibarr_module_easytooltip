Free icons from BlendIcons: https://blendicons.com

License: https://blendicons.com/page/licence / https://web.archive.org/web/20231102231619/https://blendicons.com/page/licence

Updated on November 3, 2023
